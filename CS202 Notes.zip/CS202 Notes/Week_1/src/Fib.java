// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Fib {
    public static void main(String[] args) {
        System.out.print(fib2(9));
        //System.out.print(gcd(8, 12));
    }

    //return n-th fibonacci number
    //eq：Fn = Fn-1 + Fn-2
    //runtime: O(2^n)
    //because it needs to calculate twice for each n
    static int fib1(int n) {
        if (n < 2) return n;
        return fib1(n-1) + fib1(n-2);
    }

    //runtime: O(n)
    //because it only needs to calculate n times
    static int fib2 (int n) {
        int fib_array[] = new int[n+2];

        fib_array[0] = 0;
        fib_array[1] = 1;

        for (int i = 2; i <= n; i++) {
            fib_array[i] = fib_array[i - 1] + fib_array[i - 2];
        }

        return fib_array[n];
    }

    //runtime: O(n)
    static int fib3(int n) {
        int[] fib_array2 = new int[2];
        if (n > 0) {
            fib_array2[1] = 1;
            for (int i = 2; i <= n; i++) {
                fib_array2[i % 2] = fib_array2[(i - 1) % 2] + fib_array2[(i - 2) % 2];
            }
        }
        return fib_array2[n % 2];
    }

    //runtime: O(n)
    //because it only needs to calculate n times
    static int fib4(int n) {
        int a = 0;
        int b = 0;
        for (int i = 2; i <= n; i++) {
            int c = a + b;
            a = b;
            b = c;
        }
        return b;
    }







}