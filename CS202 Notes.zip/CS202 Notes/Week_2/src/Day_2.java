
/*
Ex: Given 2 numbers x, y if n-digit each, compute x*y.

3252 * 1346 = 4382792
x: x1 x2
y: y1 y2
x = x1 * 2^n/2 + x2
y = y1 * 2^n/2 + y2
xy = x1y1*2^n + (x2y1 + x1y2) * 2^n/2 + x2y2
   = x1y1*2^n + [(x1+x2)(y1+y2) - x1y1 - x2y2] * 2^n/2 + x2y2
   //n/2 bits   // n/2 + 1 bits                          //n/2 bits
   = x1y1 * 2^n + (x1y2 + x2y1) * 2^n/2 + x2y2
 */



public class Day_2 {

}
