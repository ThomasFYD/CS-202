/*
    sorting algorithms
    merge sort, quick sort, insertion sort, selection sort, bubble sort, heap sort
    insertion sort is O(n^2) "use for small amount of elements"
    selection sort is O(n^2)
    bubble sort is O(n^2)
    quick sort is O(nlogn)
    merge sort is O(nlogn) "take half of the array then sort each half and then merge them"
    heap sort is O(nlogn)

    In java sort method appears in Arrays.sort() and Collections.sort()
    Arrays.sort():
    if primitive type, use quick sort
    if object type, use merge sort
    bcz,quick sort is stable, merge sort is not stable
    Collections.sort():
    use merge sort, bcz everything in Collections is object type

    Why merge sort is O(nlogn)?
    Because, merge sort is divide and conquer, it divides the array into two parts, and then sort each part, and then merge them
 */


public class MergeSort {
    int [] a = {3,2,6,7,1,0,9,4,8,5};


    public static void sort(int[] a, int start, int end) {
        if (start >= end) return;
        int half = start + (end - start) / 2; //(start + end)/2 may overflow
        sort(a, start, half);
        sort(a, half + 1, end);

        merge(a, start, half, end);
    }

    public static void merge(int[] a, int start, int half, int end) {
        int[] b = new int[end - start + 1];
        int i = start; // index in b
        int j = half + 1; // index in second half of a
        int k = 0; //index in a

        while (i < b.length && j < end) {
            if (b[i] <= a[j]) {
                a[k++] = b[i++];
            } else {
                a[k++] = a[j++];
            }
        }

        while (i < b.length) {
            a[k++] = b[i++];
        }
    }


}




