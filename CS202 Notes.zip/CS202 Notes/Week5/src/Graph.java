import java.util.*;
import java.io.*;

/**
 * The class for graphs and graph algorithms.
 */
public class Graph {
  // vertices are stored as (name, vertex) pairs in a Map
  Map<String, Vertex> vertexMap = new HashMap<String, Vertex>();
  int time = 0;

  public void readFromFile(String file, boolean weighted, boolean directed) {
    try {
      Scanner in = new Scanner(new File(file));

      // reading a directed weighted graph
      while (in.hasNext()) {
        String s = in.next();
        String e = in.next();
        int d = 1;
        if (weighted)
          d = in.nextInt();

        Vertex start = getVertex(s);
        Vertex end = getVertex(e);

        addDirectedEdge(start, end, d);
        if (!directed) addDirectedEdge(end, start, d);
      }
    } catch (IOException e) {
    }
  }

  /**
   * The inner class for vertices.
   */
  class Vertex {
    String name;
    boolean visited;
    int pre, post;
    List<Edge> nbs = new ArrayList<Edge>();

    /**
     * <p>
     * A constructor of an unweighted edge.
     * </p>
     * 
     * @param n vertex name
     */
    public Vertex(String n) {
      name = n;
    }

    public String toString() {
      return name;
    }

  }

  /**
   * The inner class for edges.
   */
  class Edge implements Comparable<Edge> {
    Vertex start;
    Vertex end;
    int w;

    /**
     * <p>
     * A constructor of an unweighted edge.
     * </p>
     * 
     * @param s the start vertex
     * @param e the end vertex
     */
    public Edge(Vertex s, Vertex e) {
      start = s;
      end = e;
      w = 1;
    }

    /**
     * <p>
     * A constructor of a weighted edge.
     * </p>
     * 
     * @param s the start vertex
     * @param e the end vertex
     * @param w the edge weight
     */
    public Edge(Vertex s, Vertex e, int w) {
      start = s;
      end = e;
      this.w = w;
    }

    @Override
    public int compareTo(Edge e) {
      return w - e.w;
    }

    @Override
    public String toString() {
      return start + "->" + end + ":" + w;
    }
  }

  /**
   * <p>
   * Retrun the vertex associated with the given string. create
   * a new vertex if not found.
   * </p>
   * 
   * @param s the name of vertex
   * @return the vertex associated with the given name
   */
  public Vertex getVertex(String s) {
    Vertex v = vertexMap.get(s);
    if (v == null) {
      v = new Vertex(s);
      vertexMap.put(s, v);
    }
    return v;
  }


  /**
   * <p>
   * Add a directed edge from start to end with given wight.
   * </p>
   * 
   * @param start the start vertex
   * @param end   the end vertex
   * @param end   the edge weight
   */
  public void addDirectedEdge(Vertex start, Vertex end, int w) {
    start.nbs.add(new Edge(start, end, w));
  }

  /**
   * <p>
   * Add an undirected edge between start and end with given wight.
   * </p>
   * 
   * @param start an end vertex
   * @param end   an end vertex
   * @param end   the edge weight
   */
  public void addUndirectedEdge(Vertex start, Vertex end, int w) {
    start.nbs.add(new Edge(start, end, w));
    end.nbs.add(new Edge(end, start, w));
  }

  

  /*****************************************************
   * DFS
   ****************************************************/

  /**
   * <p>
   * Recursive DFS to visit all vertices.
   * </p>
   */
  // recursive DFS
  public void DFS(Vertex u) {
    u.pre = ++time;
    for (Edge e: u.nbs) {
      Vertex v = e.end;
      if (v.pre <= 0) DFS(v);
    }
    u.post = ++time;
  }

  // iteratie DFS
  public void iDFS(Vertex u) {
    Deque<Vertex> stack = new ArrayDeque<>();
    stack.push(u);

    while(!stack.isEmpty()) {
      Vertex v = stack.pop();
      if (v.post > 0) { // v is already done
        continue;
      } else if (v.pre > 0) { // v has been previosuly visited, bit not finished
        u.post = ++time;
        continue;
      } else { //v has not been visited
        v.pre = ++time;
        stack.push(v);
        for (Edge e: v.nbs) {
          Vertex w = e.end;
          if (w.pre <= 0) {
            stack.push(w);
          }
        }
      }
    }
  }

  public boolean connected(Vertex u, Vertex v) {
    for (Vertex w: vertexMap.values()) {
      w.pre = 0;
    }
    iDFS(u);
    return v.pre > 0;
  }



    /**
   * <p>
   * Read a graph from a text file and run tests.
   * </p>
   */
  public static void main(String[] args) {

    Graph g = new Graph();
    g.readFromFile("graph1.txt", true, false);

    // g.testDfs();
    // g.testTopSort();
    // g.testScc();
    if (g.connected(g.getVertex("D"), g.getVertex("A"))) {
      System.out.println("D and A are connected");
    } else {
      System.out.println("D and A are not connected");
    }
  }
}