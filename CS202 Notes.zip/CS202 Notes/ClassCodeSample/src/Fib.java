import java.util.*;
import java.io.*;

public class Fib {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(fib2(n));
    }

    // return n-th fibonacci number
    static int fib1(int n) {
        if (n < 2) return n;
        return fib1(n-1) + fib1(n-2);
    }

    // compute n-th fibonacci number by remembering previous numbers
    static int fib2(int n) {
        int a = 0; // F[0]
        int b = 1; // F[1];
        for (int i = 2; i <= n; i++) {
            int c = a + b;
            a = b;
            b = c;
        }
        return b;
    }
}
