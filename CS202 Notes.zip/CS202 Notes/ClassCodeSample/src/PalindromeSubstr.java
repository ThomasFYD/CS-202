import java.util.*;

public class PalindromeSubstr {
    public static void main (String[] args) {
        String s = "abaab";

        System.out.println(palindromeSubstr(s));
    }

    // return the number of palindrome substrings in s
    static int palindromeSubstr(String s) {  
        int n = s.length();
        // dp[i][j] = true if the substring s[i...j] is a palindrome
        boolean[][] dp = new boolean[n][n];

        // base case dp[i][i] = true
        for (int i = 0; i < n; i++) dp[i][i] = true;

        int cnt = n;

        for(int l = 2; l <= n; l++) { // l: length of substr
            for (int i = 0; i <= n-l; i++) { // i: start index
                int j = i+l-1; // end index

                if (s.charAt(i) != s.charAt(j)) dp[i][j] = false;
                else if (l == 2 || dp[i+1][j-1]) {
                    dp[i][j] = true;
                    cnt++;
                }
            }
        }
        return cnt;
    }
}