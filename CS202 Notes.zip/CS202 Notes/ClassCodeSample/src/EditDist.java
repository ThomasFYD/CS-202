import java.util.*;

public class EditDist {
    public static void main (String[] args) {
        String S = "POLYNOMIAL";
        String T = "EXPONENTIAL";

        System.out.println(editDist(S, T));
    }

    static int editDist(String S, String T) {
        int m = S.length();
        int n = T.length();

        // dp[i][j]: edit distance between first i chars in S and first j chars in T
        int[][] dp = new int[m+1][n+1];
        int[][][] backtrack = new int[m+1][n+1][2];

        // base case: i == 0 or j == 0
        for (int j = 0; j <= n; j++) dp[0][j] = j;
        for (int i = 0; i <= m; i++) dp[i][0] = i;

        // compute dp[i][j] using recurrence relation
        for(int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (S.charAt(i-1) == T.charAt(j-1)) { // match
                    dp[i][j] = dp[i-1][j-1];
                } else {
                    dp[i][j] = dp[i-1][j-1]; // change
                    backtrack[i][j] = new int[]{i-1, j-1};
                    if (dp[i][j] > dp[i-1][j]) { // delete
                        dp[i][j] = dp[i-1][j]; 
                        backtrack[i][j] = new int[]{i-1, j};
                    }
                    if (dp[i][j] > dp[i][j-1]) { // insert
                        dp[i][j] = dp[i][j-1]; 
                        backtrack[i][j] = new int[]{i, j-1};
                    }
                    dp[i][j]++;
                }
            }
        }

        return dp[m][n];
    }
}