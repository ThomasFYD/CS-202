import java.util.*;

public class MergeSort {
  public static void main(String[] args) {
    int[] a = {3,2,6,7,1,0,9,4,8,5};
    sort(a, 0, a.length);
    System.out.println(Arrays.toString(a));
  }

  public static void sort (int[] a, int start, int end) {
    if (start >= end-1) return; 
    int half = (start+end) / 2; 
    sort(a, start, half);  
    sort(a, half, end);  
    
    merge(a, start, half, end); 
  } 


  private static void merge(int[] a, int start, int half, int end) { 
    int[] b = Arrays.copyOfRange(a, start, half); 
    
    int i = 0;  // index in b 
    int j = half;  // index in second half of a
    int k = start;  // index in merged a
    while (i < b.length && j < end ) 
      if (b[i] <= a[j]) 
        a[k++] = b[i++]; 
      else 
        a[k++] = a[j++]; 
    while (i < b.length) a[k++] = b[i++]; 
  } 
}