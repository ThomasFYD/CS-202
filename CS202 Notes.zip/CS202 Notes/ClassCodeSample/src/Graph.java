import java.util.*;
import java.io.*;

/**
 * The class for graphs and graph algorithms.
 */
public class Graph {
  // vertices are stored as (name, vertex) pairs in a Map
  Map<String, Vertex> vertexMap = new HashMap<String, Vertex>();
  ArrayList<Edge> edges = new ArrayList<>();
  int time = 0;
  int compId = 0;
  ArrayList<Vertex> topSort = new ArrayList<>();
  static int INFTY = 1000000000;

  public void readFromFile(String file, boolean weighted, boolean directed) {
    try {
      Scanner in = new Scanner(new File(file));

      // reading a directed weighted graph
      while (in.hasNext()) {
        String s = in.next();
        String e = in.next();
        int d = 1;
        if (weighted)
          d = in.nextInt();

        Vertex start = getVertex(s);
        Vertex end = getVertex(e);

        addDirectedEdge(start, end, d);
        if (!directed) addDirectedEdge(end, start, d);
      }
    } catch (IOException e) {
    }
  }

  /**
   * The inner class for vertices.
   */
  class Vertex {
    String name;
    boolean visited;
    int pre, post;
    int compId;
    Vertex parent;
    Edge prev;
    int size;
    int id;
    int dist = Integer.MAX_VALUE;
    List<Edge> nbs = new ArrayList<Edge>();

    /**
     * <p>
     * A constructor of an unweighted edge.
     * </p>
     * 
     * @param n vertex name
     */
    public Vertex(String n) {
      name = n;
    }

    public String toString() {
      return name;
    }

  }

  /**
   * The inner class for edges.
   */
  class Edge implements Comparable<Edge> {
    Vertex start;
    Vertex end;
    int w;

    /**
     * <p>
     * A constructor of an unweighted edge.
     * </p>
     * 
     * @param s the start vertex
     * @param e the end vertex
     */
    public Edge(Vertex s, Vertex e) {
      start = s;
      end = e;
      w = 1;
    }

    /**
     * <p>
     * A constructor of a weighted edge.
     * </p>
     * 
     * @param s the start vertex
     * @param e the end vertex
     * @param w the edge weight
     */
    public Edge(Vertex s, Vertex e, int w) {
      start = s;
      end = e;
      this.w = w;
    }

    @Override
    public int compareTo(Edge e) {
      return w - e.w;
    }

    @Override
    public String toString() {
      return start + "->" + end + ":" + w;
    }
  }

  /**
   * <p>
   * Retrun the vertex associated with the given string. create
   * a new vertex if not found.
   * </p>
   * 
   * @param s the name of vertex
   * @return the vertex associated with the given name
   */
  public Vertex getVertex(String s) {
    Vertex v = vertexMap.get(s);
    if (v == null) {
      v = new Vertex(s);
      vertexMap.put(s, v);
    }
    return v;
  }


  /**
   * <p>
   * Add a directed edge from start to end with given wight.
   * </p>
   * 
   * @param start the start vertex
   * @param end   the end vertex
   * @param end   the edge weight
   */
  public void addDirectedEdge(Vertex start, Vertex end, int w) {
    start.nbs.add(new Edge(start, end, w));
  }

  /**
   * <p>
   * Add an undirected edge between start and end with given wight.
   * </p>
   * 
   * @param start an end vertex
   * @param end   an end vertex
   * @param end   the edge weight
   */
  public void addUndirectedEdge(Vertex start, Vertex end, int w) {
    start.nbs.add(new Edge(start, end, w));
    end.nbs.add(new Edge(end, start, w));
  }

  public void reset() {
    for (Vertex v: vertexMap.values()) {
      v.pre = v.post = 0;
      v.visited = false;
      v.dist =  INFTY;
      v.compId = 0;
      v.prev = null;
    }
  }

  /*****************************************************
   * DFS
   ****************************************************/
  /**
   * <p>
   *  DFS that visits all vertices.
   * </p>
   */
  public void DFS() {
    // reset all pre and post timestamps
    for (Vertex v: vertexMap.values()) {
      v.pre = v.post = 0;
    }

    for (Vertex v: vertexMap.values()) {
      if (v.pre <= 0) {
        iDFS(v);
      }
    }
  }


  /**
   * <p>
   * Recursive DFS.
   * </p>
   */
  public void DFS(Vertex u) {
    u.pre = ++time;
    u.compId = compId;
    for (Edge e: u.nbs) {
      Vertex v = e.end;
      if (v.pre <= 0) DFS(v);
    }
    u.post = ++time;
  }

  // iteratie DFS
  public void iDFS(Vertex u) {
    Deque<Vertex> stack = new ArrayDeque<>();
    stack.push(u);
    u.compId = compId;

    while(!stack.isEmpty()) {
      Vertex v = stack.pop();
      if (v.post > 0) { // v is already done
        continue;
      } else if (v.pre > 0) { // v has been previosuly visited, but not finished
        v.post = ++time;
        topSort.add(u); // add u to the topSort list
        continue;
      } else { //v has not been visited
        v.pre = ++time;
        stack.push(v);
        for (Edge e: v.nbs) {
          Vertex w = e.end;
          if (w.pre <= 0) {
            stack.push(w);
          }
        }
      }
    }
  }

  public boolean connected(Vertex u, Vertex v) {
    for (Vertex w: vertexMap.values()) {
      w.pre = 0;
    }
    iDFS(u);
    return v.pre > 0;
  }


  /*****************************************************
   * Topological sort
   ****************************************************/
  public ArrayList<Vertex> topSort() {
    DFS();
    Collections.reverse(topSort);
    return topSort;
  }  

  /*****************************************************
   * Strongly Connected Components
   ****************************************************/
  public void scc() {
    Graph gr = reverse();
    ArrayList<Vertex> topSort = gr.topSort();
    reset();

    for (Vertex v: topSort) {
      if (v.pre == 0) {
        compId++;
        iDFS(v);
      }
    }
  }  

  public Graph reverse() {
    Graph gr = new Graph();
    for (Vertex v: vertexMap.values()) {
      Vertex vr = gr.getVertex(v.name);
      for (Edge e: v.nbs) {
        Vertex u = e.end;
        Vertex ur = gr.getVertex(u.name);
        gr.addDirectedEdge(ur, vr, e.w);
      }
    }
    return gr;
  }


  /*****************************************************
   * Breadth-first search
   ****************************************************/
  public void BFS(Vertex start) {  
    Queue<Vertex> Q = new ArrayDeque<>();
    Q.add(start);
    start.visited = true;
    start.dist = 0;

    while(!Q.isEmpty()) {
      Vertex v = Q.poll();
      for (Edge e: v.nbs) {
        Vertex u = e.end;
        if (!u.visited) {
          Q.add(u);
          u.visited = true;
          u.dist = v.dist+1;
        }
      }
    }
  }


  /*****************************************************
   * Dijkstra's alg
   ****************************************************/
  class PqNode implements Comparable<PqNode> {
    Vertex v;
    int dist;

    public PqNode(Vertex v_, int dist_) {
      v = v_;
      dist = dist_;
    }

    public int compareTo(PqNode other) {
      return dist - other.dist;
    }
  }

  public void dijkstra(Vertex s) {
    for (Vertex v: vertexMap.values()) v.dist = INFTY;
    PriorityQueue<PqNode> pq = new PriorityQueue<>();
    s.dist = 0;
    pq.add(new PqNode(s, 0));

    while(!pq.isEmpty()) {
      PqNode top = pq.poll();
      Vertex v = top.v;
      int dist = top.dist;

      if (dist != v.dist) continue; // ignore obsolete node
      
      for (Edge e: v.nbs) {
        Vertex u = e.end;
        if (u.dist > v.dist + e.w) {
          u.dist = v.dist + e.w;
          pq.add(new PqNode(u, u.dist));
        } 
      }
    }
  } 

  /*****************************************************
   * Bellman-Ford alg
   ****************************************************/
  void update(Edge e) {
    Vertex u = e.start;
    Vertex v = e.end;
    if (v.dist > u.dist + e.w) {
      v.dist = u.dist + e.w;
    }
  }

  public void BellmanFord(Vertex s) {
    reset();
    s.dist = 0;
    int n = vertexMap.size();
    for (int i = 0; i < n-1; i++) {
      for (Vertex v: vertexMap.values()) {
        for (Edge e: v.nbs) {
          update(e);
        }
      }
    }

    // final round to detect negative cycles
    for (Vertex v: vertexMap.values()) {
      for (Edge e: v.nbs) {
        if (e.end.dist > e.start.dist + e.w) {
          System.out.println("Negative cycle detected");
        }
      }
    }
  }


  /*****************************************************
   * Shortest path on DAG
   ****************************************************/  
  public void shortestPathDag(Vertex s) {
    ArrayList<Vertex> topSort = topSort();
    s.dist = 0;
    for (Vertex v: topSort) {
      for (Edge e: v.nbs) {
        update(e);
      }
    }
  }

  /*****************************************************
   * Kruskal's alg for MST
   ****************************************************/
  public ArrayList<Edge> kruskal() {
    ArrayList<Edge> allEdges = new ArrayList<>();
    for (Vertex v: vertexMap.values()) {
      v.parent = v;
      v.size = 1;
      for (Edge e: v.nbs) {
        allEdges.add(e);
      }
    }

    Collections.sort(allEdges);

    ArrayList<Edge> mst = new ArrayList<>();
    for (Edge e: allEdges) {
      union(e.start, e.end, e, mst);
    }
    return mst;
  }

  Vertex find(Vertex v) {
    if (v.parent == v) return v;
    return v.parent = find(v.parent); // path compression
  }

  void union(Vertex u, Vertex v, Edge e, ArrayList<Edge> mst) {
    u = find(u);
    v = find(v);
    if (u != v) {
      mst.add(e);
      if (u.size < v.size) { // union by size
        u.parent = v;
        v.size += u.size;
      } else {
        v.parent = u;
        u.size += v.size;
      }
    }
  }

  /*****************************************************
   * Prim's alg for MST
   ****************************************************/
  public ArrayList<Edge> prim(Vertex s) {
    reset();
    PriorityQueue<PqNode> pq = new PriorityQueue<>();
    ArrayList<Edge> mst = new ArrayList<>();
    pq.add(new PqNode(s, 0));
    s.dist = 0;
    s.visited = true;

    while (!pq.isEmpty()) {
      PqNode node  = pq.poll();
      Vertex v = node.v;
      int dist = node.dist;

      if (v.visited) continue;
      v.visited = true;
      mst.add(v.prev);

      for (Edge e: v.nbs) {
        Vertex u = e.end;
        if (!u.visited && u.dist > e.w) {
          u.dist = e.w;
          pq.add(new PqNode(u, u.dist));
          v.prev = e;
        }
      }
    }
    return mst;
  }

  /*****************************************************
   * Floyd-Warshall alg for all pairs shortest path
   ****************************************************/
  public int[][] floydWarshall() {
    int n = vertexMap.size();
    Vertex[] A = new Vertex[n];
    int a = A.length;

    int idx = 0;
    for (Vertex v: vertexMap.values()) {
      v.id = idx;
      A[idx++] = v;
    }

    int[][] dist = new int[n][n];
    // adjacency matrix
    for (int i = 0; i < n; i++) {
      Arrays.fill(dist, INFTY);
      for (Edge e: A[i].nbs) {
        int j = e.end.id;
        dist[i][j] = e.w;
      }
    }

    for (int k = 0; k < n; k++) {
      for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
          if (dist[i][k] < INFTY && dist[k][j] < INFTY &&
              dist[i][j] > dist[i][k] + dist[k][j]) {
                dist[i][j] = dist[i][k] + dist[k][j];
          }
        }
      }
    }

    return dist;
  }

    /**
   * <p>
   * Read a graph from a text file and run tests.
   * </p>
   */
  public static void main(String[] args) {

    Graph g = new Graph();
    g.readFromFile("large_dag.txt", false, true);

    g.DFS();


    // g.testTopSort();
    // g.testScc();


    // if (g.connected(g.getVertex("D"), g.getVertex("A"))) {
    //   System.out.println("D and A are connected");
    // } else {
    //   System.out.println("D and A are not connected");
    // }
  }
}