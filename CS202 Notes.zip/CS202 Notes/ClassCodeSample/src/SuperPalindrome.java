import java.util.*;

public class SuperPalindrome {
    public static void main (String[] args) {
        String s = "Ab5abd";

        System.out.println(superPalindrome(s));
    }

    // return the number of palindrome substrings in s
    static int superPalindrome(String s) {  
        int n = s.length();
        // dp[i][j] = # insertions to make s[i...j] a palindrome
        int[][] dp = new int[n][n];
        int[][] action = new int[n][n]; // 0: no change, 1: insert to front, 2: insert to end

        // base case dp[i][i] = 0
        for (int i = 0; i < n; i++) dp[i][i] = 0;

        for(int l = 2; l <= n; l++) { // l: length of substr
            for (int i = 0; i <= n-l; i++) { // i: start index
                int j = i+l-1; // end index

                if (s.charAt(i) != s.charAt(j)) {
                    if (dp[i+1][j] < dp[i][j-1]) {
                        dp[i][j] = dp[i+1][j]+1;
                        action[i][j] = 2; // insert to end
                    } else {
                        dp[i][j] = dp[i][j-1]+1;
                        action[i][j] = 1; // insert to front
                    }
                } else if (i < j-1) {
                    dp[i][j] = dp[i+1][j-1];
                }
            }
        }

        int i = 0; 
        int j = n-1;
        char[] newChar = new char[n+1];
        Arrays.fill(newChar, '.');

        while(i < j) {
            if (action[i][j] == 1) {
                newChar[i] = s.charAt(j);
                j--;
            } else if (action[i][j] == 2) {
                newChar[j+1] = s.charAt(i);
                i++;
            } else {
                i++;
                j--;
            }
        }

        for (int k = 0; k <= n; k++) {
            if (newChar[k] != '.') System.out.print(newChar[k]);
            if (k < n) System.out.print(s.charAt(k));
        }
        System.out.println();
        return dp[0][n-1];
    }
}