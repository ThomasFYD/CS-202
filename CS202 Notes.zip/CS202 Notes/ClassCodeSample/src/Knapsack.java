import java.util.*;

public class Knapsack {
    public static void main (String[] args) {
        int[] weights = {6, 3, 4, 2};
        int[] values = {30, 14, 16, 9};
        int W = 10;

        System.out.println(knapsack1(weights, values, W));
    }

    // without repetition, return the max value of items chosen 
    static int knapsack1(int[] weights, int [] values, int W) {
        int n = weights.length;
        int[][] dp = new int[2][W+1]; // use 2 rows to reduce space
        boolean[][] chosen = new boolean[2][W+1];
        for (int i = 1; i <= n; i++) {
            int i2 = i%2;
            int i3 = (i-1)%2;
            for (int j = 1; j <= W; j++) {
                dp[i2][j] = dp[i3][j]; // not choose item i-1
                if (weights[i-1] <= j && dp[i2][j] < dp[i3][j-weights[i-1]]) { // choose item i-1
                    dp[i2][j] = dp[i3][j-weights[i-1]];
                    chosen[i2][j] = true;
                }
            }
        }
        return dp[n%2][W];
    }

    // with repetition
    static int knapsack2(int[] weights, int [] values, int W) {
        int n = weights.length;
        int[] dp = new int[W+1];
        for (int i = 1; i <= W; i++) {
            for (int j = 0; j < n; j++) {
                if (weights[j] <= i && dp[i] < dp[i-weights[j]]+values[j]) {
                    dp[i] = dp[i-weights[j]]+values[j];
                } 
            }
        }

        return dp[W];
    }
}
