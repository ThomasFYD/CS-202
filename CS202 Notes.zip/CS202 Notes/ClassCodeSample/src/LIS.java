import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ArrayBlockingQueue;

public class LIS {
    public static void main (String[] args) {
        int[] A = {5, 2, 8, 6, 3, 6, 7, 1};

        System.out.println(lis(A));
    }

    // compute the length of the longest increasing subsequence of A
    static ArrayList<Integer> lis(int[] A) {
        int n = A.length;
        int[] dp = new int[n];
        int[] bt = new int[n];

        ArrayList<Integer> lis = new ArrayList<>();

        dp[0] = 1;
        bt[0] = -1;
        int max = 1;
        int maxIdx = 0;
        for (int i = 1; i < n; i++) {
            dp[i] = 1;
            bt[i] = -1;
            for (int j = 0; j < i; j++) {
                if (A[j] < A[i] && dp[i] < dp[j]+1) {
                    dp[i] = dp[j]+1;
                    bt[i] = j;
                }
            }
            if (dp[i] > max) {
                max = dp[i];
                maxIdx = i;
            }
        }
        for(int curr = maxIdx; curr >= 0; curr = bt[curr]) {
            lis.add(A[curr]);
        }
        Collections.reverse(lis);
        return lis;
    }
}
