import java.util.concurrent.ThreadLocalRandom;

public class Primality {
    public static void main(String[] args) {
        long n0 = 1758910381L;
        long n1 = 165319329640452469L;
        long n2 = 234452362456237L;

        System.out.println("n0 = " + n0 + " is prime? " + prime(n0));
        System.out.println("n1 = " + n1 + " is prime? " + prime(n1));
        System.out.println("n2 = " + n2 + " is prime? " + prime(n2));
        System.out.println("n0 = " + n0 + " is prime? " + primeFermat(n0));
        System.out.println("n1 = " + n1 + " is prime? " + primeFermat(n1));
        System.out.println("n2 = " + n2 + " is prime? " + primeFermat(n2));
    }

    //Not good enough for very large numbers
    static boolean prime(long n) {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n%2 == 0) return false;
        for (long i = 3; i*i <= n; i += 2) {
            if (n%i == 0) return false;
        }
        return true;
    }

    static boolean primeFermat(long n) {
        if(n < 4) {
            return n == 2 || n == 3;
        }
        for (int i = 0; i < 100; i++) {
            long a  = 2 + ThreadLocalRandom.current().nextLong(n - 2);
            if(power(a, n - 1, n) != 1) return false;
        }
        return true;
    }

    static long power(long a, long b, long n) {
        long ans = 1;
        while(b > 0) {
            if((b % 2) == 1) {//b & 1 == 1
                ans = (ans * a) % n;
            }
            a = (a * a) % n;
            b = b / 2;//b >>= 1;
        }
        return ans;
    }
}
