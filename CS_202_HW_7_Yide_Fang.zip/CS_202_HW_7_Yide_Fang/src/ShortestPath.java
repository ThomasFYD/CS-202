// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
/*
    Analyze of time complexitu:
    The time complexity for constructing the graph is O(m), where m is the number of roads.
    Initializing default values for each city has a time complexity of O(n), where n is the
    number of cities.
    The main Dijkstra's algorithm has a time complexity of O(nlogn+mlogn).
    Overall, the time complexity of the solution is O(mlogn+nlogn).
 */

import java.util.*;

public class ShortestPath {
    public static void main(String[] args) {
        List<String[]> roads = Arrays.asList(
                new String[]{"Fairview", "Madison", "7"},
                new String[]{"Fairview", "Ashland", "2"},
                new String[]{"Ashland", "Clayton", "3"},
                new String[]{"Ashland", "Hudson", "3"},
                new String[]{"Madison", "Hudson", "3"},
                new String[]{"Hudson", "Greenville", "1"},
                new String[]{"Madison", "Greenville", "1"},
                new String[]{"Clayton", "Greenville", "1"},
                new String[]{"Fairview", "Franklin", "5"},
                new String[]{"Franklin", "Madison", "2"}
        );
        int[] result = shortestPath(roads, "Fairview", "Madison");
        System.out.println(result[0] + " " + result[1]);
    }

    public static int[] shortestPath(List<String[]> roads, String start, String destination) {
        Map<String, List<Edge>> graph = new HashMap<>();
        for (String[] road : roads) {
            graph.putIfAbsent(road[0], new ArrayList<>());
            graph.putIfAbsent(road[1], new ArrayList<>());
            graph.get(road[0]).add(new Edge(road[1], Integer.parseInt(road[2])));
            graph.get(road[1]).add(new Edge(road[0], Integer.parseInt(road[2])));
        }

        Map<String, Integer> distances = new HashMap<>();
        for (String city : graph.keySet()) {
            distances.put(city, Integer.MAX_VALUE);
        }
        distances.put(start, 0);

        Map<String, Integer> ways = new HashMap<>();
        for (String city : graph.keySet()) {
            ways.put(city, 0);
        }
        ways.put(start, 1);

        PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(Comparator.comparingInt(Map.Entry::getValue));
        pq.add(new AbstractMap.SimpleEntry<>(start, 0));

        while (!pq.isEmpty()) {
            Map.Entry<String, Integer> current = pq.poll();
            String currentCity = current.getKey();
            int currentDistance = current.getValue();
            for (Edge edge : graph.get(currentCity)) {
                int newDistance = currentDistance + edge.weight;
                if (newDistance < distances.get(edge.dest)) {
                    distances.put(edge.dest, newDistance);
                    ways.put(edge.dest, ways.get(currentCity));
                    pq.add(new AbstractMap.SimpleEntry<>(edge.dest, newDistance));
                } else if (newDistance == distances.get(edge.dest)) {
                    ways.put(edge.dest, ways.get(edge.dest) + ways.get(currentCity));
                }
            }
        }

        return new int[]{distances.get(destination), ways.get(destination)};
    }

    static class Edge {
        String dest;
        int weight;

        Edge(String dest, int weight) {
            this.dest = dest;
            this.weight = weight;
        }
    }

}