// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

/*
    Time Complexity Analysis:
    The time complexity of the above algorithm is O(V + E) where V is the number of courses
    and E is the number of prerequisite relationships. This is because we are essentially
    performing a topological sort on the graph which takes O(V + E) time.
 */

import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Map<String, Integer> courseToIndex = new HashMap<>();
        List<String[]> prerequisites = new ArrayList<>();

        // Read input from file
        BufferedReader br = new BufferedReader(new FileReader("graph1.txt"));
        String line;
        int index = 0;
        while ((line = br.readLine()) != null) {
            String[] courses = line.split(" ");
            prerequisites.add(courses);
            if (!courseToIndex.containsKey(courses[0])) {
                courseToIndex.put(courses[0], index++);
            }
            if (!courseToIndex.containsKey(courses[1])) {
                courseToIndex.put(courses[1], index++);
            }
        }
        br.close();

        Graph graph = new Graph(courseToIndex.size());
        for (String[] pair : prerequisites) {
            graph.addEdge(courseToIndex.get(pair[1]), courseToIndex.get(pair[0]));
        }

        System.out.println("Minimum semesters required: " + longestPath(graph));
    }

    static int longestPath(Graph graph) {
        int[] inDegree = new int[graph.V];
        int[] length = new int[graph.V];

        for (int i = 0; i < graph.V; i++) {
            for (int v : graph.adjList[i]) {
                inDegree[v]++;
            }
        }

        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < graph.V; i++) {
            if (inDegree[i] == 0) {
                queue.add(i);
            }
        }

        while (!queue.isEmpty()) {
            int u = queue.poll();
            for (int v : graph.adjList[u]) {
                length[v] = Math.max(length[v], length[u] + 1);
                inDegree[v]--;
                if (inDegree[v] == 0) {
                    queue.add(v);
                }
            }
        }

        int maxLen = 0;
        for (int len : length) {
            maxLen = Math.max(maxLen, len);
        }
        return maxLen + 1; // +1 because we start counting from 0
    }

    static class Graph {
        int V;
        List<Integer>[] adjList;

        Graph(int V) {
            this.V = V;
            adjList = new ArrayList[V];
            for (int i = 0; i < V; i++) {
                adjList[i] = new ArrayList<>();
            }
        }

        void addEdge(int v, int w) {
            adjList[v].add(w);
        }
    }
}