import java.util.*;

public class KMerge {
    // do no change the main method
    public static void main(String[] args) {
        // generate n sorted arrays of n numbers each
        Random rand = new Random();
        int n = 2000;
        int[][] A = new int[n][n];
        for (int i = 0; i < n; i ++) {
            for (int j = 0; j < n; j++) {
                A[i][j] = rand.nextInt(1000000000);
            }
            Arrays.sort(A[i]);
        }

        // run and time the first algorithm
        long t1 = System.currentTimeMillis();
        int[] B = merge1(A, n);
        System.out.println("Merge1 runtime: " + (System.currentTimeMillis()-t1));

        // run and time the second algorithm
        t1 = System.currentTimeMillis();
        int[] C = merge2(A, n);
        System.out.println("Merge2 runtime: " + (System.currentTimeMillis()-t1));

        // make sure the results match
        if (Arrays.equals(B,C)) System.out.println("Merged arrays match!");
        else System.out.println("Merged arrays do not match!");
    }

    // add your code here
    public static int[] merge1(int[][] A, int n) {
        int[] result = A[0];
        for (int i = 1; i < n; i++) {
            result = mergeTwoSortedArrays(result, A[i]);
        }
        return result;
    }

    private static int[] mergeTwoSortedArrays(int[] A, int[] B) {
        int m = A.length;
        int n = B.length;
        int[] result = new int[m + n];
        int i = 0, j = 0, k = 0;
        while (i < m && j < n) {
            if (A[i] <= B[j]) {
                result[k++] = A[i++];
            } else {
                result[k++] = B[j++];
            }
        }
        while (i < m) {
            result[k++] = A[i++];
        }
        while (j < n) {
            result[k++] = B[j++];
        }
        return result;
    }



    public static int[] merge2(int[][] A, int n) {
        return mergeArraysRecursively(A, 0, n - 1);
    }

    private static int[] mergeArraysRecursively(int[][] A, int low, int high) {
        if (low == high) {
            return A[low];
        }
        int mid = (low + high) / 2;
        int[] left = mergeArraysRecursively(A, low, mid);
        int[] right = mergeArraysRecursively(A, mid + 1, high);
        return mergeTwoSortedArrays(left, right);
    }

}