import java.util.*;

public class LIS_Compare {
    public static void main(String[] args) {
        for (int size = 10000; size <= 100000; size += 10000) {
            int[] nums = generateRandomSequence(size);

            long startTime = System.currentTimeMillis();
            int len1 = LIS2(nums);
            long endTime = System.currentTimeMillis();
            System.out.println("O(n^2) for size " + size + ": " + (endTime - startTime) + "ms");

            startTime = System.currentTimeMillis();
            int len2 = LIS(nums);
            endTime = System.currentTimeMillis();
            System.out.println("O(n log n) for size " + size + ": " + (endTime - startTime) + "ms");

            if (len1 != len2) {
                System.out.println("Results do not match for size: " + size);
            }
        }
    }

    public static int LIS(int[] nums) {
        int[] tails = new int[nums.length];
        int size = 0;

        for (int num : nums) {
            int i = 0, j = size;
            while (i != j) {
                int mid = (i + j) / 2;
                if (tails[mid] < num) {
                    i = mid + 1;
                } else {
                    j = mid;
                }
            }
            tails[i] = num;
            if (i == size) ++size;
        }

        return size;
    }

    public static int LIS2(int[] nums) {
        if (nums == null || nums.length == 0) return 0;

        int n = nums.length;
        int[] dp = new int[n];
        int maxLen = 0;

        for (int i = 0; i < n; i++) {
            dp[i] = 1;
            for (int j = 0; j < i; j++) {
                if (nums[i] > nums[j]) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
            maxLen = Math.max(maxLen, dp[i]);
        }

        return maxLen;
    }

    public static int[] generateRandomSequence(int size) {
        Random rand = new Random();
        int[] nums = new int[size];
        for (int i = 0; i < size; i++) {
            nums[i] = rand.nextInt(1000000); // Random numbers between 0 and 999999
        }
        return nums;
    }

}