
public class Main {
    public static void main(String[] args) {

    }

    //HW1
    //b%a must less than b/2, bcz if b%a > b/2, then b%a > a, which is impossible
    //time = log(a+b)
    //so the time complexity is O(logn)
    static int gcd_1(int a, int b) {
        if (a == 0) return b;
        return gcd_1(b % a, a);
    }


    // Function to return gcd of a and b
    static int gcd_2(int a, int b) {
        while (a > 0) {
            int temp = b % a;
            b = a;
            a = temp;
        }
        return b;
    }
}