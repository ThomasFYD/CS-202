public class GCD {
    public static void main(String args[]) {
        long a = 24430498938L;
        long b = 40363433028L;

        System.out.println("GCD1: GCD of 8, 12 = " + gcd1(8, 12)); // a simple test
        // a timed test of GCD1
        long t1 = System.currentTimeMillis();
        System.out.printf("GCD1: GCD of %d, %d = %d\n", a, b, gcd1(a, b)); // should be 1062195606
        System.out.println("GCD1: Time = " + (System.currentTimeMillis() - t1) / 1000.0 + " seconds");

        System.out.println("GCD2: GCD of 8, 12 = " + gcd2(8, 12)); // a simple test
        // a timed test of GCD2
        long t2 = System.currentTimeMillis();
        System.out.printf("GCD2: GCD of %d, %d = %d\n", a, b, gcd2(a, b)); // should be 1062195606
        System.out.println("GCD2: Time = " + (System.currentTimeMillis() - t2) / 1000.0 + " seconds");
    }

    /*
    * Euclid's algorithm
    * Runtime: O(logn)
    * because b%a < b/2 and b%a < a
    * so b%a is always decreasing
    * so the time complexity is O(logn)
     */
    static long gcd1(long a, long b) {
        //assume a < b
        if (a == 0) return b;
        return gcd1(b % a, a);
    }




    /*
    * Runtime: O(logn)
    * because b%a < b/2 and b%a < a
    * so b%a is always decreasing
    * so the time complexity is O(logn)
     */
    static long gcd2(long a, long b) {
        //assume a < b
        while (a > 0) {
            long temp = b % a;
            b = a;
            a = temp;
        }
        return b;
    }
}