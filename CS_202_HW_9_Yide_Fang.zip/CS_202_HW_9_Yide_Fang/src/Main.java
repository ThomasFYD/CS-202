import java.util.*;
import java.lang.*;

public class Main {


    public static void main(String[] args) {
        String s = "Ab5abd";
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Enter the string to make it a palindrome: ");
//        String s = scanner.nextLine();
//        scanner.close();
        String palindrome = findPalindrome(s);
        System.out.println("Original string: " + s);
        System.out.println("Palindrome string: " + palindrome);
    }
    public static String findPalindrome(String s) {
        int n = s.length();
        int[][] dp = new int[n][n];

        // Fill the table
        for (int gap = 1; gap < n; gap++) {
            for (int i = 0, j = gap; j < n; i++, j++) {
                if (s.charAt(i) == s.charAt(j)) {
                    dp[i][j] = dp[i + 1][j - 1];
                } else {
                    dp[i][j] = Math.min(dp[i + 1][j], dp[i][j - 1]) + 1;
                }
            }
        }

        // Reconstructing the palindrome
        StringBuilder result = new StringBuilder();
        StringBuilder temp = new StringBuilder();

        for (int l = 0, r = s.length() - 1; l <= r; ) {
            if (s.charAt(l) == s.charAt(r)) {
                result.append(s.charAt(l));
                //System.out.println("result1: " + result);
                if (l != r) temp.insert(0, s.charAt(r)); // Append the matching character only if l != r
                l++;
                r--;
            } else if (dp[l][r] == dp[l + 1][r] + 1) {
                result.append(s.charAt(l)); // Append character from the left to the result
                temp.insert(0, s.charAt(l)); // Append the same character to temp to mirror it later
                l++;
            } else {
                result.append(s.charAt(r)); // Append character from the right to the result
                //System.out.println("result3: " + result);
                temp.insert(0, s.charAt(r)); // Append the same character to temp to mirror it later
                //System.out.println("temp3: " + temp);
                r--;
            }
        }

        //System.out.println("temp: " + temp);
        //System.out.println("result: " + result);

        // Append the reverse of the temp string to complete the palindrome
        result.append(temp);

        return result.toString();
    }
}