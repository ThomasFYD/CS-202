import java.io.*;
import java.util.*;

public class CourseScheduler {

    public static void main(String[] args) {
        // Assuming the input file is "graph.txt"
        String filename = "graph1.txt";
        CourseGraph graph;
        Map<String, Integer> courseToIndex = new HashMap<>();
        List<String> indexToCourse = new ArrayList<>();

        // Read the input file and construct the graph
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line;
            int index = 0;
            List<int[]> edges = new ArrayList<>();

            while ((line = br.readLine()) != null) {
                String[] courses = line.split(" ");
                if (!courseToIndex.containsKey(courses[0])) {
                    courseToIndex.put(courses[0], index++);
                    indexToCourse.add(courses[0]);
                }
                if (!courseToIndex.containsKey(courses[1])) {
                    courseToIndex.put(courses[1], index++);
                    indexToCourse.add(courses[1]);
                }
                edges.add(new int[]{courseToIndex.get(courses[0]), courseToIndex.get(courses[1])});
            }

            //System.out.println(indexToCourse);

            graph = new CourseGraph(index);
            for (int[] edge : edges) {
                graph.addEdge(edge[0], edge[1]);
            }

            if (graph.printCycle()) {
                System.out.println("The graph contains a cycle. Cannot complete all courses.");
            } else {
                List<Integer> order = graph.topologicalSort();
                System.out.print("Valid order to complete courses: ");
                for (int i : order) {
                    System.out.print(indexToCourse.get(i) + " ");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

