// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.*;

public class CourseGraph {
    private final int V;
    private final List<List<Integer>> adj;

    public CourseGraph(int V) {
        this.V = V;
        adj = new ArrayList<>(V);

        for (int i = 0; i < V; i++)
            adj.add(new LinkedList<>());
    }

    // This function is an implementation of DFS.
//    private boolean isCyclicUtil(int i, boolean[] visited, boolean[] recStack) {
//        if (recStack[i])
//            return true;
//
//        if (visited[i])
//            return false;
//
//        visited[i] = true;
//        //System.out.println("Visited vertex: " + i);
//        recStack[i] = true;
//
//        List<Integer> children = adj.get(i);
//
//        for (Integer c : children)
//            if (isCyclicUtil(c, visited, recStack))
//                return true;
//
//        recStack[i] = false;
//        return false;
//    }

    private List<Integer> isCyclicUtil(int i, boolean[] visited, boolean[] recStack, int[] parent) {
        if (recStack[i]) {
            List<Integer> cycle = new ArrayList<>();
            int current = i;
            do {
                cycle.add(current);
                current = parent[current];
            } while (current != i && current != -1); // Ensure we stop when the cycle is complete or if there's an invalid parent
            Collections.reverse(cycle); // To get the cycle in the correct order
            return cycle;
        }

        if (visited[i])
            return new ArrayList<>(); // Return empty list if no cycle

        visited[i] = true;
        recStack[i] = true;

        List<Integer> children = adj.get(i);

        for (Integer c : children) {
            parent[c] = i; // Update the parent of the child vertex
            List<Integer> cycle = isCyclicUtil(c, visited, recStack, parent);
            if (!cycle.isEmpty()) {
                return cycle;
            }
        }

        recStack[i] = false;
        return new ArrayList<>(); // Return empty list if no cycle
    }


    public void addEdge(int source, int dest) {
        adj.get(source).add(dest);
    }

    // Returns true if the graph contains a cycle
//    public boolean isCyclic() {
//        boolean[] visited = new boolean[V];
//        boolean[] recStack = new boolean[V];
//
//        for (int i = 0; i < V; i++)
//            if (isCyclicUtil(i, visited, recStack))
//                return true;
//
//        return false;
//    }

    public boolean printCycle() {
        boolean[] visited = new boolean[V];
        boolean[] recStack = new boolean[V];
        int[] parent = new int[V];
        Arrays.fill(parent, -1); // Initialize all parents as -1

        for (int i = 0; i < V; i++) {
            List<Integer> cycle = isCyclicUtil(i, visited, recStack, parent);
            if (!cycle.isEmpty()) {
                System.out.println("Cycle detected: " + cycle);
                return true; // Cycle detected
            }
        }
        return false; // No cycle detected
    }


    // Function to perform topological sort
    public List<Integer> topologicalSort() {
        Stack<Integer> stack = new Stack<>();
        boolean[] visited = new boolean[V];

        for (int i = 0; i < V; i++)
            if (!visited[i])
                topologicalSortUtil(i, visited, stack);

        List<Integer> order = new ArrayList<>();
        while (!stack.empty())
            order.add(stack.pop());

        return order;
    }

    private void topologicalSortUtil(int v, boolean[] visited, Stack<Integer> stack) {
        visited[v] = true;
        //System.out.println("Visited vertex: " + v);
        Integer i;
        Iterator<Integer> it = adj.get(v).iterator();
        while (it.hasNext()) {
            i = it.next();
            if (!visited[i])
                topologicalSortUtil(i, visited, stack);
        }
        stack.push(v);
    }

    // The function to read the graph from a file and test it will be implemented outside this class.
}

