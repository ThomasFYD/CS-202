import java.util.*;

public class Selection {
    static Random rand = new Random(91L);
    
    public static void main(String[] args) {
        int n = 1000000; // Do not change any code in the main method except this line

        // generate an array A of integers
        // make two identical copies so that algorithms do not affect each other
        int[] A = new int[n];
        int[] B = new int[n];
        int[] C = new int[n];
        for (int i = 0; i < n; i++) A[i] = B[i] = C[i] = rand.nextInt(n);  

        int k = rand.nextInt(n);

        // System.out.println(Arrays.toString(A) + k);

        // run and time the first algoraithm
        long t1 = System.currentTimeMillis();
        int v1 = select1(A, n, k);
        System.out.println(v1 + " algorithm 1 runtime: " + (System.currentTimeMillis()-t1));
        Arrays.sort(A);

        // run and time the second algorithm
        long t2 = System.currentTimeMillis();
        int v2 = select2(B, 0, n, k);
        System.out.println(v2 + " algorithm 2 runtime: " + (System.currentTimeMillis()-t2));

    }

    // precondition: 0 <= k < n
    // return: the k-th smallest value in A
    public static int select1(int[] A, int n, int k) {
        // add your code here
        // Sort the array A using selection sort
        Arrays.sort(A);
        // Return the k-th smallest element
        return A[k];
    }


    // precondition: start < end, 0 <= k < end-start
    // return: the k-th smallest value in the range [start, end) of A
    static int select2(int[] A, int start, int end, int k) {
        // add your code here
        if (start == end - 1) {
            return A[start]; // Base case: one element
        }

        // Partition the array around a pivot
        int pivotIndex = partition(A, start, end);

        if (k == pivotIndex - start) {
            return A[pivotIndex]; // Pivot is the k-th smallest
        } else if (k < pivotIndex - start) {
            return select2(A, start, pivotIndex, k); // Search in the left sub-array
        } else {
            return select2(A, pivotIndex + 1, end, k - (pivotIndex - start + 1)); // Search in the right sub-array
        }
    }

    private static int partition(int[] A, int start, int end) {
        //Random rand = new Random();
        int randomIndex = start + rand.nextInt(end - start);

        // Swap the random pivot element with the last element
        swap(A, randomIndex, end - 1);

        int pivot = A[end - 1];
        int i = start;

        for (int j = start; j < end - 1; j++) {
            if (A[j] <= pivot) {
                swap(A, i, j);
                i++;
            }
        }
        swap(A, i, end - 1);
        return i;
    }

    private static void swap(int[] A, int i, int j) {
        int temp = A[i];
        A[i] = A[j];
        A[j] = temp;
    }
    
}