// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

/*
Time Complexity Analysis:
The time complexity of the find operation in DSU with path compression is nearly O(1).
The union operation is also O(1). Therefore, the overall time complexity of the algorithm
is O(n + m), where n is the number of cities and m is the number of roads.
 */

import java.io.*;
import java.util.*;

public class HW4 {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("map.txt"));
        int n = Integer.parseInt(br.readLine());
        Map<String, Integer> cityMap = new HashMap<>();
        for (int i = 0; i < n; i++) {
            cityMap.put(br.readLine(), i);
        }
        int m = Integer.parseInt(br.readLine());
        UnionFind uf = new UnionFind(n);
        for (int i = 0; i < m; i++) {
            String[] road = br.readLine().split(" ");
            uf.union(cityMap.get(road[0]), cityMap.get(road[1]));
        }
        br.close();

        Set<Integer> components = new HashSet<>();
        for (int i = 0; i < n; i++) {
            components.add(uf.find(i));
        }

        System.out.println(components.size() - 1);
    }

    static class UnionFind {
        private int[] parent;
        private int[] rank;

        public UnionFind(int size) {
            parent = new int[size];
            rank = new int[size];
            for (int i = 0; i < size; i++) {
                parent[i] = i;
                rank[i] = 1;
            }
        }

        public int find(int x) {
            if (parent[x] != x) {
                parent[x] = find(parent[x]);
            }
            return parent[x];
        }

        public boolean union(int x, int y) {
            int rootX = find(x);
            int rootY = find(y);

            if (rootX == rootY) return false;

            if (rank[rootX] > rank[rootY]) {
                parent[rootY] = rootX;
            } else if (rank[rootX] < rank[rootY]) {
                parent[rootX] = rootY;
            } else {
                parent[rootY] = rootX;
                rank[rootX]++;
            }
            return true;
        }
    }
}

